package com.example.joquempo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void  selecionadoPedra (View view){
        this.opcaoSelecionada("pedra");
    }

    public void  selecionadoPapel (View view){
        this.opcaoSelecionada("papel");
    }

    public void  selecionadoTesoura (View view){
        this.opcaoSelecionada("tesoura");
    }

    public void  opcaoSelecionada (String selecionado){

        ImageView imageApp = findViewById(R.id.imageApp);
        TextView textResultado = findViewById(R.id.textResultado);

        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoApp = opcoes [numero];

        switch (opcaoApp){
            case "pedra":
                imageApp.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imageApp.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imageApp.setImageResource(R.drawable.tesoura);
                break;
        }

        if ((opcaoApp == "pedra" && selecionado == "tesoura") ||
            (opcaoApp == "papel" && selecionado == "pedra") ||
                (opcaoApp == "tesoura" && selecionado == "papel")){

            textResultado.setText("O App ganhou :(");



        }else if ((selecionado == "pedra" && opcaoApp == "tesoura") ||
                    (selecionado == "papel" && opcaoApp == "pedra") ||
                        (selecionado == "tesoura" && opcaoApp == "papel")){
            textResultado.setText("Voce ganhou :)");
        }else{
            textResultado.setText("Houve empate");
        }
    }

}